"""
The modules in this folder are used to generate the GUI and parse the results
"""
