"""
A rust program for solving FFXIV craft recipe.
 - ffcraft_solver
"""
